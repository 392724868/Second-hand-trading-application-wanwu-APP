package keshe.wanwu;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Showfenlei_det_Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_showfenlei_det_);
    }
}
